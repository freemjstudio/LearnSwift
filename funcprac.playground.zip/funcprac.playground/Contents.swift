//: Playground - noun: a place where people can play

import UIKit

var fp:(Int, Int) -> Int

fp = {
    (param1:Int, param2:Int) -> Int in
    return param1 + param2
    
}

fp(1,2)

//함수 값을 넣거나 넣지 않았을 때 내부에서 동작을 한 뒤에 결과값을 반환하거나 그렇지 않은걱ㄱ

func methodA(completion:()-> Void) {
    print("룰루랄라~~~~~")
    completion()
}

var finishMethod = {
    () -> Void in
    print("끝났음.")
}

var afterMethod = {
    () -> Void in
    print("End")
}

methodA(completion: finishMethod)
methodA(completion: afterMethod)


methodA (completion:{
    () -> Void in
    print("rrrr")
    })


var fp1:(Float, Float) -> Float

fp1 = {
    $0 + $1
}
//변수에서 지정해서 매개변수의 타입과 반환타입을 생략할 수 있다

fp1(1.0,2.0)

//기술직 문제
func getAddFunc() -> (Int,Int) -> Int {
    func getAddFunc(firstNum:Int, secondNum:Int) -> Int {
        return firstNum + secondNum
    }
    return getAddFunc
}

let myAddFunc = getAddFunc()
let result = myAddFunc(3, 4)

//---

func getNewAddFunc(firstNum:Int, secondNum:Int) -> () -> Int {
    
    func addFunc() -> Int {
        return firstNum + secondNum
    }
    return addFunc
}
let myNewAddFunc = getNewAddFunc(firstNum: 4, secondNum: 7)

let result2 = myNewAddFunc()







